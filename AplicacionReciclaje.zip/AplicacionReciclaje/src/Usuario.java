package modelo;

public class Usuario {
    private int id;
    private String nombre;
    private String rol;
    private String email;
    private String contrasena;  // <-- sin tilde

    public Usuario(int id, String nombre, String rol, String email, String contrasena) {
        this.id = id;
        this.nombre = nombre;
        this.rol = rol;
        this.email = email;
        this.contrasena = contrasena;
    }

    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getRol() { return rol; }
    public String getEmail() { return email; }
    public String getContrasena() { return contrasena; }

    // Setters
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setRol(String rol) { this.rol = rol; }
    public void setEmail(String email) { this.email = email; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public Object[] toRow() {
        return new Object[]{id, nombre, rol, email};
    }
}
