package dao;

import modelo.ResiduoElectronico;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResiduoDAO {

    public boolean registrarResiduo(ResiduoElectronico residuo) {
        String sql = "INSERT INTO residuos (tipo, peso, fecha) VALUES (?, ?, ?)";

        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, residuo.getTipo());
            pstmt.setDouble(2, residuo.getPeso());
            pstmt.setString(3, residuo.getFecha());

            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("❌ Error al registrar residuo: " + e.getMessage());
            return false;
        }
    }

    public List<ResiduoElectronico> consultarResiduos() {
        List<ResiduoElectronico> residuos = new ArrayList<>();
        String sql = "SELECT * FROM residuos";

        try (Connection conn = ConexionSQLite.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                residuos.add(new ResiduoElectronico(
                        rs.getInt("id"),
                        rs.getString("tipo"),
                        rs.getDouble("peso"),
                        rs.getString("fecha")
                ));
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al consultar residuos: " + e.getMessage());
        }
        return residuos;
    }

    public ResiduoElectronico obtenerResiduoPorId(int id) {
        String sql = "SELECT * FROM residuos WHERE id = ?";

        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new ResiduoElectronico(
                            rs.getInt("id"),
                            rs.getString("tipo"),
                            rs.getDouble("peso"),
                            rs.getString("fecha")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al obtener residuo: " + e.getMessage());
        }
        return null;
    }

    public boolean actualizarResiduo(ResiduoElectronico residuo) {
        String sql = "UPDATE residuos SET tipo = ?, peso = ?, fecha = ? WHERE id = ?";

        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, residuo.getTipo());
            pstmt.setDouble(2, residuo.getPeso());
            pstmt.setString(3, residuo.getFecha());
            pstmt.setInt(4, residuo.getId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Error al actualizar residuo: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarResiduo(int id) {
        String sql = "DELETE FROM residuos WHERE id = ?";

        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Error al eliminar residuo: " + e.getMessage());
            return false;
        }
    }

    public boolean existeId(int id) {
        String sql = "SELECT 1 FROM residuos WHERE id = ?";

        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al verificar ID de residuo: " + e.getMessage());
            return false;
        }
    }
}
