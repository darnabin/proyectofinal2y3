package modelo;

public class ResiduoElectronico {
    private int id;
    private String tipo;
    private double peso;     // <-- cambiar a double
    private String fecha;

    public ResiduoElectronico(int id, String tipo, double peso, String fecha) {
        this.id = id;
        this.tipo = tipo;
        this.peso = peso;
        this.fecha = fecha;
    }

    public int getId() { return id; }
    public String getTipo() { return tipo; }
    public double getPeso() { return peso; }
    public String getFecha() { return fecha; }

    public void setTipo(String tipo) { this.tipo = tipo; }
    public void setPeso(double peso) { this.peso = peso; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public Object[] toRow() {
        return new Object[]{id, tipo, peso, fecha};
    }
}
