import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.regex.Pattern;
import java.util.List;

import modelo.Usuario;
import modelo.CentroReciclaje;
import modelo.ResiduoElectronico;

import reportes.ReportesManager;
import rutas.GrafoRutasManager;
import modelo.CentroGrafo;

public class AplicacionReciclajeGUI {
    private JFrame frame;
    private dao.UsuarioDAO usuarioDAO;
    private dao.ResiduoDAO residuoDAO;
    private dao.CentroReciclajeDAO centroDAO;
    private ReportesManager reportesManager;
    private GrafoRutasManager grafoRutasManager = new GrafoRutasManager();

    private JTable userTable;
    private DefaultTableModel userModel;

    private JTable residuoTable;
    private DefaultTableModel residuoModel;

    private JTable centroTable;
    private DefaultTableModel centroModel;

    public AplicacionReciclajeGUI() {
        usuarioDAO = new dao.UsuarioDAO();
        residuoDAO = new dao.ResiduoDAO();
        centroDAO = new dao.CentroReciclajeDAO();
        reportesManager = new ReportesManager(residuoDAO);

        // Inicializa grafo con centros de reciclaje desde la base de datos
        inicializarGrafoRutas();

        frame = new JFrame("Aplicación de Reciclaje Electrónico");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(950, 650);
        frame.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.add("Gestión de Usuarios", createUserPanel());
        tabbedPane.add("Gestión de Residuos", createResiduoPanel());
        tabbedPane.add("Gestión de Centros", createCentroPanel());
        tabbedPane.add("Reportes", createReportesPanel());
        tabbedPane.add("Gestión de Rutas", createRutasPanel());

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void inicializarGrafoRutas() {
        List<CentroReciclaje> centros = centroDAO.consultarCentros();
        for (CentroReciclaje c : centros) {
            CentroGrafo cg = new CentroGrafo(c.getId(), c.getNombre());
            grafoRutasManager.agregarCentro(cg);
        }
    }

    // ---------------------- PANEL CENTRO DE RECICLAJE ----------------------

    private JPanel createCentroPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        centroModel = new DefaultTableModel(new String[]{"ID", "Nombre", "Ubicación", "Capacidad"}, 0);
        centroTable = new JTable(centroModel);
        cargarCentrosDesdeBD();

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        JTextField txtId = new JTextField();
        JTextField txtNombre = new JTextField();
        JTextField txtUbicacion = new JTextField();
        JTextField txtCapacidad = new JTextField();

        JButton btnAdd = new JButton("Registrar Centro");
        JButton btnDelete = new JButton("Eliminar Centro");
        JButton btnUpdate = new JButton("Actualizar Centro");
        JButton btnConsult = new JButton("Consultar Centro");

        formPanel.add(new JLabel("ID:"));
        formPanel.add(txtId);
        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(txtNombre);
        formPanel.add(new JLabel("Ubicación:"));
        formPanel.add(txtUbicacion);
        formPanel.add(new JLabel("Capacidad:"));
        formPanel.add(txtCapacidad);
        formPanel.add(btnAdd);
        formPanel.add(btnDelete);
        formPanel.add(btnConsult);
        formPanel.add(btnUpdate);

        btnAdd.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String nombre = txtNombre.getText().trim();
                String ubicacion = txtUbicacion.getText().trim();
                int capacidad = Integer.parseInt(txtCapacidad.getText().trim());

                if (nombre.isEmpty() || ubicacion.isEmpty()) {
                    mostrarError("Todos los campos deben estar completos.");
                    return;
                }

                if (capacidad <= 0) {
                    mostrarError("La capacidad debe ser un número positivo.");
                    return;
                }

                if (centroDAO.existeId(id)) {
                    mostrarError("El ID ya existe. Use otro.");
                    return;
                }

                CentroReciclaje centro = new CentroReciclaje(id, nombre, ubicacion, capacidad);
                if (centroDAO.registrarCentro(centro)) {
                    centroModel.addRow(centro.toRow());
                    limpiarCampos(txtId, txtNombre, txtUbicacion, txtCapacidad);

                    // Actualizar grafo con nuevo centro
                    CentroGrafo cg = new CentroGrafo(id, nombre);
                    grafoRutasManager.agregarCentro(cg);
                } else {
                    mostrarError("Error al registrar centro en base de datos.");
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID y capacidad deben ser números válidos.");
            }
        });

        btnConsult.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                CentroReciclaje c = centroDAO.obtenerCentroPorId(id);
                if (c != null) {
                    txtNombre.setText(c.getNombre());
                    txtUbicacion.setText(c.getUbicacion());
                    txtCapacidad.setText(String.valueOf(c.getCapacidad()));
                } else {
                    mostrarInfo("Centro no encontrado.");
                    limpiarCampos(null, txtNombre, txtUbicacion, txtCapacidad);
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID debe ser un número válido para consultar.");
            }
        });

        btnUpdate.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String nombre = txtNombre.getText().trim();
                String ubicacion = txtUbicacion.getText().trim();
                int capacidad = Integer.parseInt(txtCapacidad.getText().trim());

                if (nombre.isEmpty() || ubicacion.isEmpty()) {
                    mostrarError("Todos los campos deben estar completos.");
                    return;
                }

                if (capacidad <= 0) {
                    mostrarError("La capacidad debe ser un número positivo.");
                    return;
                }

                CentroReciclaje centro = new CentroReciclaje(id, nombre, ubicacion, capacidad);
                if (centroDAO.actualizarCentro(centro)) {
                    actualizarFilaCentro(id, nombre, ubicacion, capacidad);
                    mostrarInfo("Centro actualizado correctamente.");
                    limpiarCampos(txtId, txtNombre, txtUbicacion, txtCapacidad);
                } else {
                    mostrarError("Centro no encontrado para actualizar.");
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID y capacidad deben ser números válidos para actualizar.");
            }
        });

        btnDelete.addActionListener(e -> {
            int selectedRow = centroTable.getSelectedRow();
            if (selectedRow != -1) {
                int id = (int) centroModel.getValueAt(selectedRow, 0);
                if (centroDAO.eliminarCentro(id)) {
                    centroModel.removeRow(selectedRow);
                    limpiarCampos(txtId, txtNombre, txtUbicacion, txtCapacidad);
                    // Opcional: eliminar del grafo si tienes método para eso
                } else {
                    mostrarError("Error al eliminar centro.");
                }
            } else {
                mostrarAdvertencia("Selecciona un centro en la tabla.");
            }
        });

        panel.add(new JScrollPane(centroTable), BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void cargarCentrosDesdeBD() {
        centroModel.setRowCount(0);
        for (CentroReciclaje c : centroDAO.consultarCentros()) {
            centroModel.addRow(c.toRow());
        }
    }

    private void actualizarFilaCentro(int id, String nombre, String ubicacion, int capacidad) {
        for (int i = 0; i < centroModel.getRowCount(); i++) {
            if ((int) centroModel.getValueAt(i, 0) == id) {
                centroModel.setValueAt(nombre, i, 1);
                centroModel.setValueAt(ubicacion, i, 2);
                centroModel.setValueAt(capacidad, i, 3);
                break;
            }
        }
    }

    private JPanel createRutasPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JComboBox<String> origenBox = new JComboBox<>();
        JComboBox<String> destinoBox = new JComboBox<>();
        JTextField txtDistancia = new JTextField();

        JButton btnAgregarConexion = new JButton("Agregar Conexión");
        JButton btnCalcularRuta = new JButton("Calcular Ruta Más Corta");

        JTextArea txtResultado = new JTextArea(5, 40);
        txtResultado.setEditable(false);

        // Cargar centros desde BD y comboBoxes
        List<CentroReciclaje> centros = centroDAO.consultarCentros();
        origenBox.removeAllItems();
        destinoBox.removeAllItems();
        for (CentroReciclaje c : centros) {
            origenBox.addItem(c.getNombre());
            destinoBox.addItem(c.getNombre());
        }

        btnAgregarConexion.addActionListener(e -> {
            try {
                String origenNombre = (String) origenBox.getSelectedItem();
                String destinoNombre = (String) destinoBox.getSelectedItem();
                double distancia = Double.parseDouble(txtDistancia.getText().trim());

                if (origenNombre.equals(destinoNombre)) {
                    mostrarError("El origen y destino no pueden ser iguales.");
                    return;
                }

                if (distancia <= 0) {
                    mostrarError("Distancia debe ser positiva.");
                    return;
                }

                CentroGrafo origen = obtenerCentroGrafoPorNombre(origenNombre);
                CentroGrafo destino = obtenerCentroGrafoPorNombre(destinoNombre);

                if (origen == null || destino == null) {
                    mostrarError("No se pudo encontrar uno de los centros seleccionados.");
                    return;
                }

                grafoRutasManager.agregarConexion(origen, destino, distancia);
                mostrarInfo("Conexión agregada exitosamente.");
                txtDistancia.setText("");
            } catch (NumberFormatException ex) {
                mostrarError("La distancia debe ser un número válido.");
            }
        });

        btnCalcularRuta.addActionListener(e -> {
            String origenNombre = (String) origenBox.getSelectedItem();
            String destinoNombre = (String) destinoBox.getSelectedItem();

            CentroGrafo origen = obtenerCentroGrafoPorNombre(origenNombre);
            CentroGrafo destino = obtenerCentroGrafoPorNombre(destinoNombre);

            if (origen == null || destino == null) {
                mostrarError("No se pudo encontrar uno de los centros seleccionados.");
                return;
            }

            List<CentroGrafo> ruta = grafoRutasManager.encontrarRutaMasCorta(origen, destino);

            if (ruta == null || ruta.isEmpty()) {
                mostrarAdvertencia("No se encontró ruta entre " + origenNombre + " y " + destinoNombre);
                return;
            }

            StringBuilder rutaTexto = new StringBuilder();
            for (CentroGrafo c : ruta) {
                rutaTexto.append(c.getNombre()).append(" → ");
            }
            if (rutaTexto.length() > 4)
                rutaTexto.setLength(rutaTexto.length() - 3);

            double distanciaTotal = grafoRutasManager.calcularDistanciaTotal(ruta);

            String mensaje = "Ruta más corta desde " + origenNombre + " a " + destinoNombre + ":\n" +
                    rutaTexto + "\nDistancia total: " + String.format("%.2f", distanciaTotal) + " km";

            JOptionPane.showMessageDialog(frame, mensaje, "Resultado Ruta", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.add(new JLabel("Origen:"));
        inputPanel.add(origenBox);
        inputPanel.add(new JLabel("Destino:"));
        inputPanel.add(destinoBox);
        inputPanel.add(new JLabel("Distancia (km):"));
        inputPanel.add(txtDistancia);
        inputPanel.add(btnAgregarConexion);
        inputPanel.add(btnCalcularRuta);

        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(txtResultado), BorderLayout.CENTER);
        return panel;
    }

    private CentroGrafo obtenerCentroGrafoPorNombre(String nombre) {
        for (CentroReciclaje c : centroDAO.consultarCentros()) {
            if (c.getNombre().equals(nombre)) {
                return new CentroGrafo(c.getId(), c.getNombre());
            }
        }
        return null;
    }

    private JPanel createReportesPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JTextArea areaReportes = new JTextArea();
        areaReportes.setEditable(false);
        areaReportes.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(areaReportes);

        JButton btnResumen = new JButton("Generar Resumen de Residuos");
        JButton btnPorTipo = new JButton("Residuos por Tipo");

        btnResumen.addActionListener(e -> {
            String reporte = reportesManager.generarResumenResiduos();
            areaReportes.setText(reporte);
        });

        btnPorTipo.addActionListener(e -> {
            String reporte = reportesManager.generarReportePorTipo();
            areaReportes.setText(reporte);
        });

        JPanel botonera = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botonera.add(btnResumen);
        botonera.add(btnPorTipo);

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botonera, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createUserPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        userModel = new DefaultTableModel(new String[]{"ID", "Nombre", "Rol", "Email"}, 0);
        userTable = new JTable(userModel);
        cargarUsuariosDesdeBD();

        JPanel formPanel = new JPanel(new GridLayout(7, 2, 5, 5));
        JTextField txtId = new JTextField();
        JTextField txtNombre = new JTextField();
        JTextField txtRol = new JTextField();
        JTextField txtEmail = new JTextField();
        JTextField txtPassword = new JTextField();

        JButton btnAddUser = new JButton("Registrar Usuario");
        JButton btnDeleteUser = new JButton("Eliminar Usuario");
        JButton btnUpdateUser = new JButton("Actualizar Usuario");
        JButton btnConsultUser = new JButton("Consultar Usuario");

        formPanel.add(new JLabel("ID:"));
        formPanel.add(txtId);
        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(txtNombre);
        formPanel.add(new JLabel("Rol:"));
        formPanel.add(txtRol);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(txtEmail);
        formPanel.add(new JLabel("Contraseña:"));
        formPanel.add(txtPassword);
        formPanel.add(btnAddUser);
        formPanel.add(btnDeleteUser);
        formPanel.add(btnConsultUser);
        formPanel.add(btnUpdateUser);

        btnAddUser.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String nombre = txtNombre.getText().trim();
                String rol = txtRol.getText().trim();
                String email = txtEmail.getText().trim();
                String password = txtPassword.getText();

                if (nombre.isEmpty() || rol.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    mostrarError("Todos los campos deben estar completos.");
                    return;
                }

                if (!isValidEmail(email)) {
                    mostrarError("El email no tiene un formato válido.");
                    return;
                }

                if (usuarioDAO.existeId(id)) {
                    mostrarError("El ID ya existe. Use otro.");
                    return;
                }

                Usuario usuario = new Usuario(id, nombre, rol, email, password);
                if (usuarioDAO.registrarUsuario(usuario)) {
                    userModel.addRow(usuario.toRow());
                    limpiarCampos(txtId, txtNombre, txtRol, txtEmail, txtPassword);
                } else {
                    mostrarError("Error al registrar usuario en base de datos.");
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID debe ser un número entero válido.");
            }
        });

        btnConsultUser.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                Usuario u = usuarioDAO.obtenerUsuarioPorId(id);
                if (u != null) {
                    txtNombre.setText(u.getNombre());
                    txtRol.setText(u.getRol());
                    txtEmail.setText(u.getEmail());
                    txtPassword.setText(u.getContrasena());
                } else {
                    mostrarInfo("Usuario no encontrado.");
                    limpiarCampos(null, txtNombre, txtRol, txtEmail, txtPassword);
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID debe ser un número válido para consultar.");
            }
        });

        btnUpdateUser.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String nombre = txtNombre.getText().trim();
                String rol = txtRol.getText().trim();
                String email = txtEmail.getText().trim();
                String password = txtPassword.getText();

                if (nombre.isEmpty() || rol.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    mostrarError("Todos los campos deben estar completos.");
                    return;
                }

                if (!isValidEmail(email)) {
                    mostrarError("El email no tiene un formato válido.");
                    return;
                }

                Usuario usuario = new Usuario(id, nombre, rol, email, password);
                if (usuarioDAO.actualizarUsuario(usuario)) {
                    actualizarFilaUsuario(id, nombre, rol, email);
                    mostrarInfo("Usuario actualizado correctamente.");
                    limpiarCampos(txtId, txtNombre, txtRol, txtEmail, txtPassword);
                } else {
                    mostrarError("Usuario no encontrado para actualizar.");
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID debe ser un número válido para actualizar.");
            }
        });

        btnDeleteUser.addActionListener(e -> {
            int selectedRow = userTable.getSelectedRow();
            if (selectedRow != -1) {
                int id = (int) userModel.getValueAt(selectedRow, 0);
                if (usuarioDAO.eliminarUsuario(id)) {
                    userModel.removeRow(selectedRow);
                    limpiarCampos(txtId, txtNombre, txtRol, txtEmail, txtPassword);
                } else {
                    mostrarError("Error al eliminar usuario.");
                }
            } else {
                mostrarAdvertencia("Selecciona un usuario en la tabla.");
            }
        });

        panel.add(new JScrollPane(userTable), BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void cargarUsuariosDesdeBD() {
        userModel.setRowCount(0);
        for (Usuario u : usuarioDAO.consultarUsuarios()) {
            userModel.addRow(u.toRow());
        }
    }

    private void actualizarFilaUsuario(int id, String nombre, String rol, String email) {
        for (int i = 0; i < userModel.getRowCount(); i++) {
            if ((int) userModel.getValueAt(i, 0) == id) {
                userModel.setValueAt(nombre, i, 1);
                userModel.setValueAt(rol, i, 2);
                userModel.setValueAt(email, i, 3);
                break;
            }
        }
    }

    private JPanel createResiduoPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        residuoModel = new DefaultTableModel(new String[]{"ID", "Tipo", "Peso", "Fecha"}, 0);
        residuoTable = new JTable(residuoModel);
        cargarResiduosDesdeBD();

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        JTextField txtId = new JTextField();
        JTextField txtTipo = new JTextField();
        JTextField txtPeso = new JTextField();
        JTextField txtFecha = new JTextField();

        JButton btnAdd = new JButton("Registrar Residuo");
        JButton btnDelete = new JButton("Eliminar Residuo");
        JButton btnUpdate = new JButton("Actualizar Residuo");
        JButton btnConsult = new JButton("Consultar Residuo");

        formPanel.add(new JLabel("ID:"));
        formPanel.add(txtId);
        formPanel.add(new JLabel("Tipo:"));
        formPanel.add(txtTipo);
        formPanel.add(new JLabel("Peso:"));
        formPanel.add(txtPeso);
        formPanel.add(new JLabel("Fecha (YYYY-MM-DD):"));
        formPanel.add(txtFecha);
        formPanel.add(btnAdd);
        formPanel.add(btnDelete);
        formPanel.add(btnConsult);
        formPanel.add(btnUpdate);

        btnAdd.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String tipo = txtTipo.getText().trim();
                float peso = Float.parseFloat(txtPeso.getText().trim());
                String fecha = txtFecha.getText().trim();

                if (tipo.isEmpty() || fecha.isEmpty()) {
                    mostrarError("Todos los campos deben estar completos.");
                    return;
                }

                if (peso <= 0) {
                    mostrarError("El peso debe ser un número positivo.");
                    return;
                }

                if (!isValidFecha(fecha)) {
                    mostrarError("La fecha debe tener formato YYYY-MM-DD.");
                    return;
                }

                if (residuoDAO.existeId(id)) {
                    mostrarError("El ID ya existe. Use otro.");
                    return;
                }

                ResiduoElectronico residuo = new ResiduoElectronico(id, tipo, peso, fecha);
                if (residuoDAO.registrarResiduo(residuo)) {
                    residuoModel.addRow(residuo.toRow());
                    limpiarCampos(txtId, txtTipo, txtPeso, txtFecha);
                } else {
                    mostrarError("Error al registrar residuo en base de datos.");
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID y peso deben ser números válidos.");
            }
        });

        btnConsult.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                ResiduoElectronico r = residuoDAO.obtenerResiduoPorId(id);
                if (r != null) {
                    txtTipo.setText(r.getTipo());
                    txtPeso.setText(String.valueOf(r.getPeso()));
                    txtFecha.setText(r.getFecha());
                } else {
                    mostrarInfo("Residuo no encontrado.");
                    limpiarCampos(null, txtTipo, txtPeso, txtFecha);
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID debe ser un número válido para consultar.");
            }
        });

        btnUpdate.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String tipo = txtTipo.getText().trim();
                float peso = Float.parseFloat(txtPeso.getText().trim());
                String fecha = txtFecha.getText().trim();

                if (tipo.isEmpty() || fecha.isEmpty()) {
                    mostrarError("Todos los campos deben estar completos.");
                    return;
                }

                if (peso <= 0) {
                    mostrarError("El peso debe ser un número positivo.");
                    return;
                }

                if (!isValidFecha(fecha)) {
                    mostrarError("La fecha debe tener formato YYYY-MM-DD.");
                    return;
                }

                ResiduoElectronico residuo = new ResiduoElectronico(id, tipo, peso, fecha);
                if (residuoDAO.actualizarResiduo(residuo)) {
                    actualizarFilaResiduo(id, tipo, peso, fecha);
                    mostrarInfo("Residuo actualizado correctamente.");
                    limpiarCampos(txtId, txtTipo, txtPeso, txtFecha);
                } else {
                    mostrarError("Residuo no encontrado para actualizar.");
                }
            } catch (NumberFormatException ex) {
                mostrarError("ID y peso deben ser números válidos para actualizar.");
            }
        });

        btnDelete.addActionListener(e -> {
            int selectedRow = residuoTable.getSelectedRow();
            if (selectedRow != -1) {
                int id = (int) residuoModel.getValueAt(selectedRow, 0);
                if (residuoDAO.eliminarResiduo(id)) {
                    residuoModel.removeRow(selectedRow);
                    limpiarCampos(txtId, txtTipo, txtPeso, txtFecha);
                } else {
                    mostrarError("Error al eliminar residuo.");
                }
            } else {
                mostrarAdvertencia("Selecciona un residuo en la tabla.");
            }
        });

        panel.add(new JScrollPane(residuoTable), BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void cargarResiduosDesdeBD() {
        residuoModel.setRowCount(0);
        for (ResiduoElectronico r : residuoDAO.consultarResiduos()) {
            residuoModel.addRow(r.toRow());
        }
    }

    private void actualizarFilaResiduo(int id, String tipo, float peso, String fecha) {
        for (int i = 0; i < residuoModel.getRowCount(); i++) {
            if ((int) residuoModel.getValueAt(i, 0) == id) {
                residuoModel.setValueAt(tipo, i, 1);
                residuoModel.setValueAt(peso, i, 2);
                residuoModel.setValueAt(fecha, i, 3);
                break;
            }
        }
    }

    // Métodos auxiliares para mostrar mensajes y validar email y fecha

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(frame, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarInfo(String mensaje) {
        JOptionPane.showMessageDialog(frame, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(frame, mensaje, "Advertencia", JOptionPane.WARNING_MESSAGE);
    }

    private void limpiarCampos(JTextField... campos) {
        for (JTextField campo : campos) {
            if (campo != null) campo.setText("");
        }
    }

    private boolean isValidEmail(String email) {
        String regex = "^[\\w-.]+@[\\w-]+\\.[a-z]{2,}$";
        return Pattern.matches(regex, email.toLowerCase());
    }

    private boolean isValidFecha(String fecha) {
        return Pattern.matches("^\\d{4}-\\d{2}-\\d{2}$", fecha);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AplicacionReciclajeGUI());
    }
}

