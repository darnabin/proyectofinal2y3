package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexionSQLite {
    private static final String URL = "jdbc:sqlite:mi_base_de_datos.db";

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Error cargando driver SQLite: " + e.getMessage());
        }
    }

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void crearTablasSiNoExisten() {
        String sqlUsuarios = "CREATE TABLE IF NOT EXISTS usuarios (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT NOT NULL," +
                "rol TEXT NOT NULL," +
                "email TEXT NOT NULL," +
                "contrasena TEXT NOT NULL" +    // <-- sin tilde
                ");";

        String sqlResiduos = "CREATE TABLE IF NOT EXISTS residuos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +   // <-- AUTOINCREMENT
                "tipo TEXT NOT NULL," +
                "peso REAL NOT NULL," +
                "fecha TEXT NOT NULL" +
                ");";

        String sqlCentros = "CREATE TABLE IF NOT EXISTS centros_reciclaje (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT NOT NULL," +
                "ubicacion TEXT NOT NULL," +
                "capacidad INTEGER NOT NULL" +
                ");";

        try (Connection conn = conectar();
             Statement stmt = conn.createStatement()) {

            stmt.execute(sqlUsuarios);
            stmt.execute(sqlResiduos);
            stmt.execute(sqlCentros);

            System.out.println("✅ Tablas creadas o verificadas con éxito.");
        } catch (SQLException e) {
            System.err.println("❌ Error creando tablas: " + e.getMessage());
        }
    }
}
