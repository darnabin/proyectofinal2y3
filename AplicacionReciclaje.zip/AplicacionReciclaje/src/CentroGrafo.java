package modelo;

public class CentroGrafo {
    private int id;
    private String nombre;

    public CentroGrafo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CentroGrafo)) return false;
        CentroGrafo centro = (CentroGrafo) o;
        return id == centro.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
