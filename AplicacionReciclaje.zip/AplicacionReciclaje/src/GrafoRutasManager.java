package rutas;

import modelo.CentroGrafo;

import java.util.*;

/**
 * Clase para representar un grafo de centros de reciclaje y
 * gestionar rutas (camino más corto) entre ellos.
 */
public class GrafoRutasManager {
    private final Map<CentroGrafo, List<Arista>> adyacencias = new HashMap<>();

    /**
     * Agrega un centro al grafo si no existe.
     */
    public void agregarCentro(CentroGrafo centro) {
        adyacencias.putIfAbsent(centro, new ArrayList<>());
    }

    /**
     * Agrega una ruta bidireccional entre dos centros con un peso (distancia).
     */
    public void agregarConexion(CentroGrafo origen, CentroGrafo destino, double distancia) {
        agregarCentro(origen);
        agregarCentro(destino);
        adyacencias.get(origen).add(new Arista(destino, distancia));
        adyacencias.get(destino).add(new Arista(origen, distancia));
    }

    /**
     * Encuentra la ruta más corta entre dos centros usando algoritmo de Dijkstra.
     * @return Lista de centros que conforman la ruta, o lista vacía si no existe ruta.
     */
    public List<CentroGrafo> encontrarRutaMasCorta(CentroGrafo inicio, CentroGrafo fin) {
        if (!adyacencias.containsKey(inicio) || !adyacencias.containsKey(fin)) {
            System.err.println("Uno o ambos centros no existen en el grafo.");
            return Collections.emptyList();
        }

        Map<CentroGrafo, Double> distancias = new HashMap<>();
        Map<CentroGrafo, CentroGrafo> anteriores = new HashMap<>();
        PriorityQueue<NodoRuta> cola = new PriorityQueue<>(Comparator.comparingDouble(n -> n.distancia));

        for (CentroGrafo centro : adyacencias.keySet()) {
            distancias.put(centro, Double.MAX_VALUE);
        }
        distancias.put(inicio, 0.0);
        cola.add(new NodoRuta(inicio, 0.0));

        while (!cola.isEmpty()) {
            NodoRuta actual = cola.poll();
            CentroGrafo actualCentro = actual.centro;

            if (actualCentro.equals(fin)) break;

            for (Arista arista : adyacencias.getOrDefault(actualCentro, Collections.emptyList())) {
                double nuevaDistancia = distancias.get(actualCentro) + arista.peso;
                if (nuevaDistancia < distancias.getOrDefault(arista.destino, Double.MAX_VALUE)) {
                    distancias.put(arista.destino, nuevaDistancia);
                    anteriores.put(arista.destino, actualCentro);
                    cola.add(new NodoRuta(arista.destino, nuevaDistancia));
                }
            }
        }

        return reconstruirRuta(anteriores, inicio, fin);
    }

    /**
     * Calcula la distancia total de una ruta dada.
     * @return suma de distancias o -1 si hay tramo sin conexión.
     */
    public double calcularDistanciaTotal(List<CentroGrafo> ruta) {
        if (ruta == null || ruta.size() < 2) return 0;

        double distanciaTotal = 0.0;

        for (int i = 0; i < ruta.size() - 1; i++) {
            CentroGrafo origen = ruta.get(i);
            CentroGrafo destino = ruta.get(i + 1);

            double distancia = getDistancia(origen, destino);
            if (distancia < 0) {
                System.err.println("No existe conexión entre " + origen + " y " + destino);
                return -1;
            }
            distanciaTotal += distancia;
        }
        return distanciaTotal;
    }

    private List<CentroGrafo> reconstruirRuta(Map<CentroGrafo, CentroGrafo> anteriores,
                                              CentroGrafo inicio, CentroGrafo fin) {
        LinkedList<CentroGrafo> ruta = new LinkedList<>();
        CentroGrafo actual = fin;

        while (actual != null && !actual.equals(inicio)) {
            ruta.addFirst(actual);
            actual = anteriores.get(actual);
        }
        if (actual == null) return Collections.emptyList();
        ruta.addFirst(inicio);
        return ruta;
    }

    private double getDistancia(CentroGrafo origen, CentroGrafo destino) {
        List<Arista> aristas = adyacencias.get(origen);
        if (aristas != null) {
            for (Arista arista : aristas) {
                if (arista.destino.equals(destino)) {
                    return arista.peso;
                }
            }
        }
        return -1; // No hay conexión directa
    }

    // Clase interna para representar aristas (conexiones)
    private static class Arista {
        final CentroGrafo destino;
        final double peso;

        Arista(CentroGrafo destino, double peso) {
            this.destino = destino;
            this.peso = peso;
        }
    }

    // Nodo usado en cola de prioridad para Dijkstra
    private static class NodoRuta {
        final CentroGrafo centro;
        final double distancia;

        NodoRuta(CentroGrafo centro, double distancia) {
            this.centro = centro;
            this.distancia = distancia;
        }
    }
}
