package dao;

import modelo.CentroReciclaje;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dao.ConexionSQLite;

public class CentroReciclajeDAO {

    public boolean registrarCentro(CentroReciclaje centro) {
        String sql = "INSERT INTO centros_reciclaje (nombre, ubicacion, capacidad) VALUES (?, ?, ?)";

        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, centro.getNombre());
            pstmt.setString(2, centro.getUbicacion());
            pstmt.setInt(3, centro.getCapacidad());

            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("❌ Error al registrar centro: " + e.getMessage());
            return false;
        }
    }

    public List<CentroReciclaje> consultarCentros() {
        List<CentroReciclaje> lista = new ArrayList<>();
        String sql = "SELECT * FROM centros_reciclaje";

        try (Connection conn = ConexionSQLite.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                CentroReciclaje c = new CentroReciclaje(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("ubicacion"),
                        rs.getInt("capacidad")
                );
                lista.add(c);
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al consultar centros: " + e.getMessage());
        }
        return lista;
    }

    public boolean existeId(int id) {
        String sql = "SELECT 1 FROM centros_reciclaje WHERE id = ?";

        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al verificar ID de centro: " + e.getMessage());
            return false;
        }
    }

    public CentroReciclaje obtenerCentroPorId(int id) {
        String sql = "SELECT * FROM centros_reciclaje WHERE id = ?";
        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new CentroReciclaje(
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("ubicacion"),
                            rs.getInt("capacidad")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al obtener centro: " + e.getMessage());
        }
        return null;
    }

    public boolean actualizarCentro(CentroReciclaje centro) {
        String sql = "UPDATE centros_reciclaje SET nombre = ?, ubicacion = ?, capacidad = ? WHERE id = ?";
        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, centro.getNombre());
            pstmt.setString(2, centro.getUbicacion());
            pstmt.setInt(3, centro.getCapacidad());
            pstmt.setInt(4, centro.getId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Error al actualizar centro: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarCentro(int id) {
        String sql = "DELETE FROM centros_reciclaje WHERE id = ?";
        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Error al eliminar centro: " + e.getMessage());
            return false;
        }
    }

}

