package reportes;

import dao.ResiduoDAO;
import modelo.ResiduoElectronico;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportesManager {
    private final ResiduoDAO residuoDAO;

    public ReportesManager(ResiduoDAO residuoDAO) {
        this.residuoDAO = residuoDAO;
    }

    public String generarResumenResiduos() {
        List<ResiduoElectronico> lista = residuoDAO.consultarResiduos();
        float totalPeso = 0f;
        for (ResiduoElectronico r : lista) {
            totalPeso += r.getPeso();
        }
        return "Total de residuos registrados: " + lista.size() +
                "\nPeso total: " + totalPeso + " kg";
    }

    public String generarReportePorTipo() {
        List<ResiduoElectronico> lista = residuoDAO.consultarResiduos();
        Map<String, Double> mapa = new HashMap<>();
        for (ResiduoElectronico r : lista) {
            mapa.put(r.getTipo(), mapa.getOrDefault(r.getTipo(), 0.0) + r.getPeso());
        }

        StringBuilder sb = new StringBuilder("Reporte por Tipo de Residuo:\n");
        for (Map.Entry<String, Double> entry : mapa.entrySet()) {
            sb.append(entry.getKey()).append(": ").append(entry.getValue()).append(" kg\n");
        }


        return sb.toString();
    }
}
